const db = require("../models");
const Chart = db.charts;
const Op = db.Sequelize.Op;


// Create and Save a new record
exports.create = async function (req, res, next) {
    // Validate request
    if (!req.body.name) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
        return;
    }

    // Create a data
    const chartInfo = {
        name: req.body.name,
        age: req.body.age,
        gender: req.body.gender
    };

    // Save data in the database
    let resultData = await Chart.create(chartInfo);

    if (!resultData) {
        throw new HttpException(500, 'Something went wrong');
    } else {
        res.status(201).send('Record was created!');
        res.send(resultData);
    }


};

// Retrieve all records from the database.
exports.findAll = async function (req, res, next) {

    const name = req.query.name;
    var condition = name ? {name: {[Op.like]: `%${name}%`}} : null;
    let resultData = await Chart.findAll({where: condition});

    if (!resultData.length) {
        throw new HttpException(404, 'Records not found');
    }
    res.send(resultData);

};


// find barchart data point
exports.findBarDataPoint = async function (req, res, next) {


    let resultData = [];
    let barChartPoints = "";
    let noOfYAdult = 0;
    let noOfAdult = 0;
    let noOfSenior = 0;
    const name = req.query.name;
    var condition = name ? {name: {[Op.like]: `%${name}%`}} : null;

    resultData = await Chart.findAll({where: condition});

    if (resultData.length !== 0) {
        resultData.map((chart) => {

                if (chart.age <= 35) {
                    noOfYAdult++;
                } else if (chart.age > 35 && chart.age < 51) {
                    noOfAdult++;
                } else noOfSenior++;


            }
        )
    }

    barChartPoints = {
        "noOfYAdult": noOfYAdult,
        "noOfAdult": noOfAdult,
        "noOfSenior": noOfSenior
    }


    if (!resultData.length) {
        throw new HttpException(404, 'Records not found');
    } else {
        res.send(barChartPoints);
    }


};

// find piechart data point
exports.findPieDataPoint = async function (req, res, next) {
    let resultData = [];
    let pieChartDPoints = "";
    let noOfMale = 0;
    let noOfFemale = 0;
    const name = req.query.name;
    var condition = name ? {name: {[Op.like]: `%${name}%`}} : null;
    resultData = await Chart.findAll({where: condition});

    if (resultData.length !== 0) {
        resultData.map((chart) => {
            if (chart.gender === "F") {
                noOfFemale++
            } else {
                noOfMale++
            }

        })
        pieChartDPoints = {
            "noOfFemale": noOfFemale,
            "noOfMale": noOfMale
        }


    }

    if (!resultData.length) {
        throw new HttpException(404, 'Records not found');
    } else {
        res.send(pieChartDPoints);
    }


};

//async-await
/*Async/await is the lastest and smarter approach to write asynchronous code. 
It Increases the performance and responsiveness of the application, 
particularly when you have long-running operations that do not require to block the execution.
In this case, you can perform other work while waiting for the result from the long-running task.
The big difference is that asynchronous code written with Async/Await looks and behaves like synchronous code.
With Async/Await less code is needed to write and it's more readable than callback and promise approach.
*/