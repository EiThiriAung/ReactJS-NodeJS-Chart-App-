module.exports = (sequelize, Sequelize) => {
    const ChartData = sequelize.define("charts", {
        name: {
            type: Sequelize.STRING
        },
        age: {
            type: Sequelize.INTEGER
        },
        gender: {
            type: Sequelize.STRING
        }
    });

    return ChartData;
};