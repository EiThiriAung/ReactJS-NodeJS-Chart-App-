module.exports = app => {
    const charts = require("../controllers/chart.controller.js");
    var router = require("express").Router();

    //create a new row of record
    router.post("/", charts.create);

    //retriee all records from charts table
    router.get("/", charts.findAll);

    //produce data points for bar chart
    router.get("/bar", charts.findBarDataPoint);

    //produce data points for pie chart
    router.get("/pie", charts.findPieDataPoint);

    app.use("/api/charts", router);
}