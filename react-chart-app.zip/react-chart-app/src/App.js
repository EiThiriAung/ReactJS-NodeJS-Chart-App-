import React, {Component} from "react";
import {Switch, Route, Link} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import {Scrollbars} from 'react-custom-scrollbars';
import FontAwesome from 'react-fontawesome'
import faStyles from 'font-awesome/css/font-awesome.css'

import AddChart from "./components/AddChartComponent";
import ChartInfo from "./components/ChartInfoComponent";

class App extends Component {
    render() {
        return (
            <div>
                <nav className="navbar navbar-expand navar-bar-style">
                    <a href="/chartinfo" className="navbar-brand">
                        <div className="position-relative"> &nbsp;<i
                            className="fa fa-bar-chart fa-1.5x bar-chart-style"></i><label
                            className="header-title"> Chart App</label></div>
                    </a>

                </nav>
                <Scrollbars style={{height: 500}}>
                    <div className="container mt-3">
                        <Switch>
                            <Route exact path={["/", "/chartinfo"]} component={ChartInfo}/>
                            <Route exact path="/addchart" component={AddChart}/>
                        </Switch>
                    </div>
                </Scrollbars>
            </div>
        );
    }
}

export default App;
