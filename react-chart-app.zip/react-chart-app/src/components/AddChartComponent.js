import React, {Component} from "react";
import ChartDataService from "../services/chart-service";
import "./BarPieChart.css";

export default class AddChartData extends Component {
    constructor(props) {
        super(props);

        this.state = {
            id: null,
            name: "",
            age: 18,
            gender: "female",
            errorMessage: "",
            showErrorAlert: false,
            isLoading: false,
        };
    }

    handleChangeRecord(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
    }


    handleSaveNewData() {
        var genderInfo = "F";
        if (this.state.gender === "male") {
            genderInfo = "M";
        }
        var data = {
            name: this.state.name,
            age: parseInt(this.state.age),
            gender: genderInfo
        };
        this.setState({
            isLoading: true
        })
        ChartDataService.create(data)
            .then(response => {
                this.props.history.push('/chartinfo')

            })
            .catch(e => {
                console.log("error in creating");
                console.log(e);
                this.setState({
                    errorMessage: "Please Fill All Records!",
                    showErrorAlert: true,
                    isLoading: false
                })
            });

        //.then()
        /*If develop your frontend with React.js,
        a typical use case might be to display a loading screen until a fetch request returns and then
        using a setState to update the UI.
        */
    }

    handleCancelAddForm() {
        this.props.history.push('/chartinfo')
    }


    render() {
        return (
            <div>
                {
                    this.state.showErrorAlert ?
                        <div className="alert alert-warning alert-dismissible fade show" role="alert">
                            {this.state.errorMessage}
                            <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"
                                    onClick={() => this.setState({showErrorAlert: false})}></button>

                        </div>
                        :
                        null
                }
                <div
                    className="submit-form position-absolute  start-50 col-5 translate-middle-x p-3 justify-item-center  mt-5 shadow-lg p-3 mb-5 bg-body rounded">
                    {
                        this.state.isLoading ?
                            <div className="loading-popup">
                                <div className="spinner-grow text-info" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                                <div className="spinner-grow text-info" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                                <div className="spinner-grow text-info" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            :
                            null
                    }

                    <div>
                        <div className="form-group">
                            <label id="name">Name</label>
                            <input
                                type="text"
                                className="form-control"
                                id="name"
                                required
                                value={this.state.name}
                                onChange={this.handleChangeRecord.bind(this)}
                                name="name"
                                placeholder="Name"
                            />
                        </div>

                        <div className="form-group">
                            <label id="age">Age</label>
                            <input
                                type="number"
                                className="form-control"
                                id="age"
                                required
                                value={this.state.age}
                                onChange={this.handleChangeRecord.bind(this)}
                                name="age"
                                placeholder="Age"
                            />
                        </div>
                        <div className="form-group">
                            <label>Gender</label>
                            <div className="row">
                                <div className="col-4">
                                    <input
                                        type="radio"
                                        id="female"
                                        checked={this.state.gender === "female"}
                                        onChange={this.handleChangeRecord.bind(this)}
                                        name="gender"
                                        value="female"
                                    /><label className="form-check-label p-d-3">

                                    Female
                                </label>
                                </div>
                                <div className="col-4">
                                    <input
                                        type="radio"
                                        id="male"
                                        checked={this.state.gender === "male"}
                                        onChange={this.handleChangeRecord.bind(this)}
                                        name="gender"
                                        value="male"
                                    /><label className="form-check-label">
                                    Male
                                </label>
                                </div>
                            </div>

                        </div>
                        <div className="mt-4 pt-2">
                            <button onClick={this.handleSaveNewData.bind(this)}
                                    className="btn btn-outline-success me-md-2" disabled={this.state.isLoading}>
                                <i className="fa fa-save fa-1.5x"></i> Save
                            </button>
                            <button onClick={this.handleCancelAddForm.bind(this)} className="btn btn-outline-primary"
                                    disabled={this.state.isLoading}>
                                <i className="fa fa-remove fa-1.5x"></i> Cancel
                            </button>
                        </div>

                    </div>

                </div>


            </div>

        )
    }
}