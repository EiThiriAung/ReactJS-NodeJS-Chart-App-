import React, {Component} from "react";
import ChartDataService from "../services/chart-service";
import {Link} from "react-router-dom";
import {CanvasJSChart} from 'canvasjs-react-charts';
import "./BarPieChart.css";

export default class ChartList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            chartInformations: [],
            pieChartOptions: [],
            barChartOptions: [],
            isLoading: true,
            isShowError: false,
        };
    }

    componentDidMount() {
        this.retrieveChartInfo();
    }


    retrieveChartInfo() {

        let pieChartPoints = [];
        let resultData = [];
        let barChartPoints = [];
        let piePoints = "";
        let barPoints = "";
        let pieChart = "";
        let barChart = "";


        ChartDataService.getPieDataPoints()
            .then(pie => {

                console.log("pie chartInformations", pie.data)
                piePoints = pie.data


                pieChartPoints = [
                    {y: piePoints.noOfFemale, label: "Female"},
                    {y: piePoints.noOfMale, label: "Male"}
                ]


                pieChart = {
                    exportEnabled: true,
                    animationEnabled: true,
                    title: {
                        text: "Pie Chart"
                    },
                    data: [{
                        type: "pie",
                        startAngle: 75,
                        toolTipContent: "<b>{label}</b>: {y}%",
                        showInLegend: "true",
                        legendText: "{label}",
                        indexLabelFontSize: 16,
                        indexLabel: "{label} - {y}%",
                        dataPoints: pieChartPoints
                    }]
                }


                ChartDataService.getBarDataPoints()
                    .then(bar => {

                        console.log("chart list info", bar.data);
                        barPoints = bar.data


                        barChartPoints = [
                            {y: barPoints.noOfYAdult, label: "young adult (0-35)"},
                            {y: barPoints.noOfAdult, label: "adult (36-50)"},
                            {y: barPoints.noOfSenior, label: "senior (51-above)"}
                        ]


                        barChart = {
                            animationEnabled: true,
                            theme: "light2",
                            title: {
                                text: "Bar Chart"
                            },
                            axisX: {
                                title: "Age Group",
                                reversed: true,
                            },
                            axisY: {
                                title: "No Of People",
                                includeZero: true,
                                labelFormatter: this.addSymbols
                            },
                            data: [{
                                type: "bar",
                                dataPoints: barChartPoints
                            }]
                        }


                        this.setState({
                            chartInformations: resultData,
                            pieChartOptions: pieChart,
                            barChartOptions: barChart,
                            isLoading: false,
                        });
                        console.log(bar.data);
                    })
                    .catch(e => {
                        console.log(e);
                    });

            })
            .catch(e => {
                console.log(e);
                this.setState({
                    isShowError: true,
                    isLoading: false,
                })
            });


    }

    handleGoToAddChartPage() {
        this.props.history.push('/addchart')
    }


    render() {

        const myScrollbar = {
            width: 400,
            height: 400,
        };

        return (

            <div className="container">

                {
                    !this.state.isLoading ?

                        <div>
                            <div className="row">
                                <button type="button" className="btn btn-outline-primary col-md-1"
                                        onClick={this.handleGoToAddChartPage.bind(this)}><i
                                    className="fa fa-plus fa-1.5x"></i> New
                                </button>
                            </div>
                            {
                                !this.state.isShowError ?
                                    <div>
                                        <div className="row">


                                            <CanvasJSChart options={this.state.pieChartOptions}
                                                           draggingFromParent={true}
                                                /* onRef={ref => this.chart = ref} */

                                            />
                                            {/*You can get reference to the chart instance as shown above using onRef. This allows you to access all chart properties and methods*/}

                                        </div>
                                        <div className="row mt-5">

                                            <CanvasJSChart options={this.state.barChartOptions}
                                                /* onRef={ref => this.chart = ref} */
                                            />
                                            {/*You can get reference to the chart instance as shown above using onRef. This allows you to access all chart properties and methods*/}

                                        </div>
                                    </div>
                                    :
                                    <div className="alert alert-info" role="alert">
                                        There is no record !.
                                    </div>
                            }

                        </div>

                        :
                        <div className="p-3 d-flex justify-content-center list-page-loading-style">
                            <div className="spinner-grow text-info" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                            <div className="spinner-grow text-info" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                            <div className="spinner-grow text-info" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                        </div>

                }


            </div>
        )
    }
}