import http from "../http-common";

class ChartDataService {
    getAll() {
        return http.get("/charts");
    }

    create(data) {
        return http.post("/charts", data);
    }

    getPieDataPoints(id, data) {
        return http.get(`/charts/pie`);
    }

    getBarDataPoints(id) {
        return http.get(`/charts/bar`);
    }

}

export default new ChartDataService();